using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DealOrNoDeal.Models{


    public class dealornoclass{
        
        public static int _cantOfertas=0;
        public static int _maletinesAbiertos=0;
         public static int _ultimoMaletin=0;
        public static int _jugadasRestantes=7;
        public static double[] _ofertas = new double[6];

        /*private float[] _importesAuxiliar;*/
        public static float[] _importes = new float[26]{1, 5, 10, 15, 25, 50, 75, 100, 200, 300, 400, 500, 
        750, 1000, 5000, 10000, 25000, 50000, 75000, 100000, 200000, 300000, 400000, 500000, 750000, 
        1000000};

        /*private int[] _nroMaletines = new int[26]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26}; */
        public int _maletinElegido;
        public static int _contador=0;
        private static Maletin[] _maletines;


    public int MaletinElegido{
            get{
                return _maletinElegido;
            }
            set{
                _maletinElegido=value;
            }
        }
        public int UltimoMaletin{
            get{
                return _ultimoMaletin;
            }
            set{
                _ultimoMaletin=value;
            }
        }
           public int CantOfertas{
            get{
                return _cantOfertas;
            }
           }

        public int Contador{
            get{
                return _contador;
            }
            set{
                _contador=value;
            }
        }
        public int MaletinesAbiertos{
            get{
                return _maletinesAbiertos;
            }
            set{
                _maletinesAbiertos=value;
            }
        }
            public float[] Importes{
            get{
                return _importes;
            }
            
        }

        public int JugadasRestantes{
            get{
                return _jugadasRestantes;
            }
            set{
                _jugadasRestantes = value;
            }
            
        }

        /*public float[] ImportesAuxiliar{
            get{
                return _importesAuxiliar;
            }
            set{
                _importesAuxiliar = value;
            }
        }
        */


            public Maletin[] Maletines{
            get{
                return _maletines;
            }
            set{
                _maletines= value;
            }
        }
        public dealornoclass(int maletinElegido){
            if(_jugadasRestantes==6){
                _maletinElegido = maletinElegido;
            }
                        
        }

        public void IniciarJuego(int Maletin){
            
            Random aleatorio=new Random();
            _maletines=new Maletin [26];
            float[] _importesAuxiliar;
            
           _importesAuxiliar = new float[26]{1, 5, 10, 15, 25, 50, 75, 100, 200, 300, 400, 500, 
        750, 1000, 5000, 10000, 25000, 50000, 75000, 100000, 200000, 300000, 400000, 500000, 750000, 
        1000000};

            for (int i=0;i<26;i++){
                int posicion;
                posicion=aleatorio.Next(0,26);

                while(_importesAuxiliar[posicion]==-1){
                    posicion=aleatorio.Next(0,26);
            
                }

                _maletines[i]=new Maletin(i+1,_importes[posicion]);
                
                _importesAuxiliar[posicion]=-1;

            }

        }

        public float AbrirMaletin(int Numero){
            float valor;
            if(_maletinesAbiertos>=24){
                
                _ultimoMaletin=Numero;
                return -65;
            }
            else{
            if(_maletines[Numero].Estado == false){

                _jugadasRestantes=_jugadasRestantes-1;
                _maletines[Numero].Estado=true;
                _maletinesAbiertos=_maletinesAbiertos+1;
             
            
                return _importes[Numero];
            }
            else{
                 valor=-1;
                return valor;
                }

            /*while(true){
                Console.WriteLine("Standard Numeric Format Specifiers");
            }
            */
        }
         }

        public int Jugadasrestantes(){

            return _jugadasRestantes;
        }
public int devolverUltimoMaletin(){

            return _ultimoMaletin;
        }

        public int devolverMaletinInicial(){

            return _maletinElegido;
        }
        public double OfertaBanca(){
           double ofertaBanca;
           ofertaBanca=-1;
           float sumaImportes;
           int maletinesNoAbiertos;
           sumaImportes=0;
           maletinesNoAbiertos=0;

            _cantOfertas=_cantOfertas+1;

            for (int i=0;i<26;i++){

                if(_maletines[i].Estado==false)
                sumaImportes=_maletines[i].Importe+sumaImportes;
                maletinesNoAbiertos=maletinesNoAbiertos+1;

            }
            ofertaBanca=sumaImportes/maletinesNoAbiertos;
            ofertaBanca=ofertaBanca*0.85;
            _ofertas[_cantOfertas-1]=ofertaBanca;
            
            return ofertaBanca;
        }

        public float Final(){
            
            return _importes[_maletinElegido];
            
        }

        public double DecisionOferta(bool aceptar){
         

            if(aceptar==true){
   
                return _ofertas[_cantOfertas];

            }
            else{
            
            _contador=_contador+1;
            switch (_contador)
            {
                case 1:
       
                    _jugadasRestantes=6;
                   break;
                case 2:
            
                    _jugadasRestantes=5;

                    break;
                case 3:
                    _jugadasRestantes=3;
                    break;
                case 4:
                    _jugadasRestantes=2;
                break;
                 case 5:
                    _jugadasRestantes=1;
                break;
                default: 
                    _jugadasRestantes=1;
                    break;

                    
            }
            return -1;
        }
        }

        public Maletin[] DevolverListaMaletines(){

            return _maletines;
        }

        public float[] DevolverListaImportes(){
            
            
            
            return _importes;
        }

 

    }
    
}