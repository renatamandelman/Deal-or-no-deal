using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DealOrNoDeal.Models{

public class Maletin{
    private int _nroMaletin;
    private float _importe;
    private bool _estado;

    

            public int NroMaletin{
            get{
                return _nroMaletin;
            }
            set{
                _nroMaletin = value;
            }
        }

            public float Importe{
            get{
                return _importe;
            }
            set{
                _importe = value;
            }
        }

            public bool Estado{
            get{
                return _estado;
            }
            set{
                _estado = value;
            }
        }

public Maletin(int nroMaletin, float importe){
            _nroMaletin=nroMaletin;
            _importe=importe;
            _estado=false;
    }
}
}