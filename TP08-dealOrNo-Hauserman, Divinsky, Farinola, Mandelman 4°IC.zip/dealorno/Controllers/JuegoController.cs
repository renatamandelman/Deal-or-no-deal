using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using DealOrNoDeal.Models;

namespace DealOrNoDeal.Controllers
{
    public class JuegoController : Controller
    {
        private readonly ILogger<JuegoController> _logger;
    
        // public static Maletin[] _maletines;
        private static int maletinesAbiertos=0;
        private static float ultimoMaletin;
        private static float maletinInicial;
        private static dealornoclass juego;

        public JuegoController(ILogger<JuegoController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            ViewBag.color="blanco";
            juego=new dealornoclass(87);
            
            ViewBag.importes=juego.DevolverListaImportes();
            return View();

        }
     
        public IActionResult elegirPrimerMaletin(int maletin)
        {
           ViewBag.color="blanco";
            juego=new dealornoclass(maletin);
            juego.IniciarJuego(maletin);
           
            //cosas fijas / para las views
            ViewBag.maletinElegido=maletin;
            ViewBag.maletines=juego.DevolverListaMaletines();
            ViewBag.importes=juego.DevolverListaImportes();
           ViewBag.maletinElegido=juego.devolverMaletinInicial();

        
            return View("juego");
        }

        public IActionResult eleccionMaletin(int maletin)
        {   
           
            ViewBag.maletinesAbiertos=maletinesAbiertos;
            
            ViewBag.color="blanco";
          
            float valor;
            
            juego = new dealornoclass(maletin);

            valor=juego.AbrirMaletin(maletin);
            
            if (valor==-1){

                ViewBag.maletines=juego.DevolverListaMaletines();
                ViewBag.importes=juego.DevolverListaImportes();
                ViewBag.JugadasRestantes=juego.Jugadasrestantes();
               
                ViewBag.maletinElegido=juego.devolverMaletinInicial();
                return View("juego");
            }
            else if (valor==-65){
               
                ultimoMaletin=juego.devolverUltimoMaletin();
                ViewBag.ultimoMaletin=ultimoMaletin+1;
                maletinInicial=juego.devolverMaletinInicial();
                ViewBag.maletinElegido=maletinInicial+1;
                return View("ultimosDos");
            }
            else{
                if(juego.Jugadasrestantes()==0){

                    ViewBag.oferta=juego.OfertaBanca();
                    return View("decision");

                }

                else{

                    ViewBag.maletines=juego.DevolverListaMaletines();
                    ViewBag.JugadasRestantes=juego.Jugadasrestantes();
                    ViewBag.importes=juego.DevolverListaImportes();
                    ViewBag.maletinElegido=juego._maletinElegido;
                    return View("juego");

                }
            }

        }

       
        public IActionResult ultimosDos(bool eleccion){
            if(eleccion==true){
                               
                Maletin[] _maletines = new Maletin[26];
                _maletines=juego.DevolverListaMaletines();

                int maletin = (int)ultimoMaletin;
                ViewBag.importeGanado=_maletines[maletin].Importe;
                return View("final");
            }
            else{
                Maletin[] _maletines = new Maletin[26];
                _maletines=juego.DevolverListaMaletines();

                int maletin = (int)maletinInicial;
                ViewBag.importeGanado=_maletines[maletin].Importe;
                return View("final");
            }
          
        }
        public IActionResult decision(bool aceptar){
            ViewBag.color="blanco";
            juego=new dealornoclass(8);
            double valor;
            valor=juego.DecisionOferta(aceptar);

            if(valor!=-1){
                
                ViewBag.importeGanado=valor;
                return View("final");
            }
            else{
                ViewBag.maletines=juego.DevolverListaMaletines();
                    ViewBag.importes=juego.DevolverListaImportes();
                    ViewBag.JugadasRestantes=juego.Jugadasrestantes();
                    ViewBag.maletinElegido=juego._maletinElegido;
                    
                        return View("juego");
                    
               

            }
        }
/*
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        */
    }
}
